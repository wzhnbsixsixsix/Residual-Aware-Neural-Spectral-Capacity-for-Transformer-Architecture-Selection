# Proposal 修改追溯

## 2026-10-13 — 创建 CS5491 一页 project proposal

- `Proposal/body.tex`：新增英文正文，包含组员信息、问题动机、方法、数据划分、基线、评价指标、LLM 型号/访问方式/调用预算和课程里程碑。按用户给出的姓名、学号及邮箱填写；ZHAO deyi 学号明确留空待补充。
- `proposal.tex`：新增独立课程 proposal 入口，使用 A4、12pt Times New Roman、2.5cm 页边距和单倍行距；避免原论文模板的封面、摘要和参考文献。
- `proposal_overleaf.tex`：由同一正文导出可一次性复制的完整 LaTeX 文件，方便用户粘贴到 Overleaf。
- `scripts/render_proposal.py`：新增受限正文转换器，用于本机无 XeLaTeX 时生成 PDF；内嵌字体、检查一页、输出未填字段数，并同步单文件 Overleaf 版本。
- `output/pdf/project_proposal.pdf`：生成并视觉检查一页 PDF；目前仅 ZHAO deyi 学号待填写，尚非可直接提交的最终稿。
- `PROPOSAL_README.md`：记录正文位置、Overleaf 编译步骤、缺失信息、模型假设、原始资料链接、复现方式与本地未编译 LaTeX 的限制。
- `README.md`：加入课程 proposal 入口提示，保留原学位论文模板说明。

验证：PDF 一页，A4，字体嵌入，字号 12pt；渲染 PNG 检查无溢出、重叠或裁切。LaTeX 文件尚未在本机编译。未运行任何拟议实验，未发送付费 LLM 请求。只提交本次 proposal 相关文件，其他课程及原模板文件不纳入此次提交。

## 2026-10-14 — 改为用户指定的 NSC Direction 1

- `Proposal/body.tex`：全面替换 FunSearch 方案为 FFN 串联投影依赖研究；补充参考模型、明确公式与假设、原 NSC 消融、数值/不变性检查、200 架构固定划分、完整排名和预算选择基线、归档限制及先计时再决定训练的计划。保留已有组员信息，未编造缺失学号。
- `scripts/render_proposal.py`：PDF 元数据标题同步新选题。
- `proposal_overleaf.tex`、`output/pdf/project_proposal.pdf`：从同一正文重新生成。
- `PROPOSAL_README.md`：替换旧选题说明，记录实际 NSC 来源、代理公式推导与限制、无实验 LLM 调用、待补学号及生成方法。
- 校验：生成器确认一页 A4、12pt 内嵌 Times New Roman；另执行最终 PDF 渲染与文字边界检查。未运行研究实验，未声称已完成训练计时；未提交 Canvas。

## 2026-10-14 — 核对本次材料并完善 proposal

- `Proposal/body.tex`：精炼英文一页正文；明确 J=W2 D W1、独立门控、c=0.5 和均值 Gram 代入的假设；保留单一机制与原 NSC 消融，补充固定参数分配检查及条件性重排训练计划。未虚构实验结果或缺失学号。
- `scripts/render_proposal.py`：支持 `\textsuperscript{}`，修复 Times New Roman 缺少 Unicode 上标 4 导致的方框；公式使用正常上标排版。
- `proposal_overleaf.tex`、`output/pdf/project_proposal.pdf`：由统一正文重新导出，并检查最终 PDF。
- `PROPOSAL_README.md`：同步独立门控假设，修正本项目选题 PDF 的相对路径，移除无关 FunSearch 来源描述，记录 starter 尚未取得、截止时间及 Canvas 提交要求。
- `README.md`：更新 proposal 日期。
- 验证：最终 PDF 为一页 A4；正文 12pt Times New Roman、四周至少 2.5cm；视觉检查无方框、重叠或裁切，无摘要和参考文献列表。LaTeX 因本机无 XeLaTeX 未编译。ZHAO deyi 学号待用户提供，当前 PDF 不应直接提交。未运行训练或归档实验，未提交 Canvas。

## 2026-10-14 — 补齐用户确认的组员学号

- `Proposal/body.tex`：按用户提供的信息将 ZHAO deyi 学号填写为 72655668。
- `proposal_overleaf.tex`、`output/pdf/project_proposal.pdf`：同步重新生成，无待填字段。
- `README.md`、`PROPOSAL_README.md`：移除当前待补学号提示，保留历史记录。
- 验证：一页 A4、正文 12pt Times New Roman、四周 2.5cm，检查最终渲染；尚未提交 Canvas。

## 2026-10-14 — 按用户确认的 A 方案改为单个残差块建模

- 决策依据：先与用户讨论机制，用户选择残差连接、归档为主训练可选，再选择 A（单块而非跨层传播），并明确要求实施该计划。
- `Proposal/body.tex`：更新标题、动机与方法为 FFN 残差 J=I+B；明确独立 Gaussian 权重、Bernoulli(0.5) 门控和固定 identity 归一化近似；采用减去 identity-only 容量的拟议目标。配对消融只去掉 shortcut，原 NSC 独立保留。补充零/弱分支、数值误差和顺序不变性边界，保留课程完整评估要求及里程碑，明确 starter 和实验未完成。组员信息不变。
- `scripts/render_proposal.py`：同步 PDF 元数据标题。
- `proposal_overleaf.tex`、`output/pdf/project_proposal.pdf`：由统一正文重新生成残差方案。
- `PROPOSAL_README.md`：重写研究设计、公式含义、消融区别、估计器尚待开发验证、归档与训练边界、复现步骤及提交状态；历史方案仅保留在本修改记录中。
- `README.md`：入口注明已共同确定的单个 FFN 残差块方向。
- 验证：PDF 一页 A4、内嵌 Times New Roman、正文 12pt、字符位于四周 2.5cm 边界内；最终图像无重叠、缺字或裁切；Overleaf 单文件与统一正文一致，无待填字段，无摘要和参考文献列表。LaTeX 因本机无 XeLaTeX 未编译；未运行研究实验或训练。
- 按本次批准计划创建本地提交；此前推送审批限制尚未解除，不尝试远端推送，不提交 Canvas。
