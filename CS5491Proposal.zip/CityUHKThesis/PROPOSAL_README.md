# CS5491 NSC Direction 1 proposal

## 文件与格式

- 标题：**Residual-Aware Neural Spectral Capacity for Transformer Architecture Selection**。
- 正文：`Proposal/body.tex`；PDF：`output/pdf/project_proposal.pdf`。
- Overleaf：复制 `proposal_overleaf.tex` 为 `main.tex`，选择 XeLaTeX；也可上传 `proposal.tex` 和 `Proposal/body.tex`。
- 一页 A4、Times New Roman 正文 12pt、四周 2.5cm、单倍行距，无摘要、无参考文献列表。
- 原 `thesis.tex` 是学位论文模板，不是本次提交入口。

## 已确认组员信息

WANG Zenghuan（72655030）、ZHAO deyi（72655668）；联系邮箱 w905840774@gmail.com。
截止时间为 2026-10-15 23:59 BJT，每组在 Canvas 提交一份 PDF。尚未提交 Canvas。

## 用户确定的研究方向

采用 Direction 1 的 **A：单个 FFN 残差子块建模**。核心是 identity shortcut 的贡献，而非跨层残差传播或层顺序预测。归档评估和数值检查构成完整项目；新增训练先计时、再决定，不预先承诺训练面板。

### 参考模型与贡献

令 W1 为 f×d、W2 为 d×f，B=W2 D W1，残差块 Jacobian 为 J=I+B。参考模型采用独立零均值 Gaussian 权重，标准差 s=0.02；D 的对角元素采用独立 Bernoulli(0.5)，且与权重独立。归一化近似为固定 identity 映射。门控与归一化均为研究的简化假设，不声称是归档模型的精确激活导数或归一化 Jacobian。实施研究前检查归档实际配置。

定义 C(A)=ln det(I+AᵀA)。拟议残差贡献为 E[C(I+B)]−d ln 2；减去 C(I)=d ln 2，确保 B=0 时贡献为零。移除 shortcut 的配对消融为 E[C(B)]，保留完全相同的分支模型和估计条件。原始 NSC 则保留原来两个 FFN 投影容量之和，作为独立基线。注意力评分、初始化与投影分组保持固定。

上述表达式定义拟研究的目标，不是已经验证的闭式估计器。期望不能随意替换为均值 Gram 的 logdet。估计方式将在开发阶段通过小矩阵采样、零分支和弱分支检查、误差与评分成本评估后确定，并在最终集评估前冻结。零基线校正后的单次贡献不保证非负，不应未经说明截断。层贡献仍然相加，重排必须保持分数不变，不能声称能预测顺序效应。

### 评估与范围

- 课程 200 架构归档、固定 100/100 开发/最终划分。
- 基线：原始 NSC、shortcut 消融、位置示例、报告参数量及参考 FLOPs；预算选择另加重复均匀随机选择。
- 排名：相对负 perplexity 的 Spearman、Kendall tau-b、并列与耗时；同宽度且总参数量相差不超过 10% 的比较及其数量。
- 选择：10M、20M、30M、50M 参数上限，k=1、3，使用相同可行池，报告最佳所选 perplexity 及相对可行最优的 regret。
- 区分随机选择变化与训练种子不确定性；异质归档不支持因果结论，每架构单一结果无法估计训练种子不确定性。
- 新训练先记录硬件、吞吐、峰值内存，再确定是否安排固定数据划分、参数预算和训练设置的匹配架构实验。
- November 19：复现基线、估计器与开发结果；December 3：冻结最终评估与可复现代码。

尚未取得 `nsc-starter.zip`，未核验其实际代码，也未运行研究实验或训练。本次交付仅更新 proposal。实验不使用 LLM，API 调用预算为 0；这不表示文稿未使用写作辅助。

## 依据

- `../5491project description.markdown`：proposal 内容、Section 1.3 格式与截止时间。
- `../topic-neural-spectral-capacity.pdf`：Direction 1、归档规模、参考约定、基线与评估要求。
- 本方案中的残差贡献与配对消融是拟研究设计，不能描述成课程已提供或已验证的方法。

## 重新生成

安装 `reportlab`、`pypdf` 后，在本目录执行：

```sh
python3 scripts/render_proposal.py
```

脚本读取唯一正文，生成内嵌 macOS Times New Roman 的 PDF，检查一页并同步 Overleaf 单文件。只支持本文有限 LaTeX 命令。本机无 XeLaTeX，因此 PDF 使用 ReportLab 生成；LaTeX 未本地编译，Overleaf 编译后需重新检查页数。不要通过缩小字号或页边距容纳正文。

## 提交状态

按用户批准的本次范围，仅创建本地 Git 提交。此前推送被自动审批拒绝；仍待用户确认具体 GitHub 仓库及分支的推送授权。不提交 Canvas。历史修改记录见 `PROPOSAL_CHANGELOG.md`。
