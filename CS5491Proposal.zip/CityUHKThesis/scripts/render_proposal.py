"""Render the restricted proposal LaTeX body with ReportLab when XeLaTeX is absent.

The submitted content comes only from Proposal/body.tex. This is a local PDF
renderer, not a general TeX compiler; Overleaf should compile proposal.tex.
"""
from pathlib import Path
import re
from xml.sax.saxutils import escape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[1]
FONT = Path('/System/Library/Fonts/Supplemental')
for face, filename in [('TNR', 'Times New Roman.ttf'), ('TNR-Bold', 'Times New Roman Bold.ttf')]:
    pdfmetrics.registerFont(TTFont(face, str(FONT / filename)))
pdfmetrics.registerFontFamily('TNR', normal='TNR', bold='TNR-Bold', italic='TNR', boldItalic='TNR-Bold')


def plain(value):
    """Convert the small set of inline commands used in the proposal."""
    value = escape(value.strip())
    value = re.sub(r'\\textbf\{([^{}]*)\}', r'<b>\1</b>', value)
    value = re.sub(r'\\texttt\{([^{}]*)\}', r'\1', value)
    value = re.sub(r'\\textsuperscript\{([^{}]*)\}', r'<super>\1</super>', value)
    value = value.replace(r'\noindent', '').replace(r'\\', '<br/>')
    value = value.replace(r'\%', '%').replace(r'$\times$', '&#215;')
    value = value.replace('--', '&#8211;')
    if '\\' in value or '$' in value:
        raise ValueError(f'Unsupported TeX markup: {value}')
    return value


text = (ROOT / 'Proposal/body.tex').read_text()
text = re.sub(r'^%.*\n', '', text, flags=re.M)
center = re.search(r'\\begin\{center\}(.*?)\\end\{center\}', text, re.S)
base = ParagraphStyle('body', fontName='TNR', fontSize=12, leading=14.4, spaceAfter=5)
title = ParagraphStyle('title', parent=base, alignment=1, spaceAfter=8)
story = [Paragraph(plain(center.group(1)), title)]
remaining = text[center.end():].strip()
for block in re.split(r'\n\s*\n', remaining):
    block = re.sub(r'\\paragraph\{([^{}]*)\}', r'\\textbf{\1} ', block)
    story.append(Paragraph(plain(block), base))
out = ROOT / 'output/pdf/project_proposal.pdf'
out.parent.mkdir(parents=True, exist_ok=True)
SimpleDocTemplate(str(out), pagesize=A4, leftMargin=2.5*cm, rightMargin=2.5*cm,
                  topMargin=2.5*cm, bottomMargin=2.5*cm,
                  title='Residual-Aware Neural Spectral Capacity for Transformer Architecture Selection',
                  author='WANG Zenghuan; ZHAO deyi').build(story)
pdf = PdfReader(out)
assert len(pdf.pages) == 1, f'Expected one page, got {len(pdf.pages)}'
print('Unfilled fields:', pdf.pages[0].extract_text().count('[TO FILL]'))
print(f'Created {out}; pages={len(pdf.pages)}; A4; embedded Times New Roman; 12pt; 2.5cm margins.')

# Export one copy-and-paste file for Overleaf from the same canonical body.
wrapper = (ROOT / 'proposal.tex').read_text()
(ROOT / 'proposal_overleaf.tex').write_text(wrapper.replace(r'\input{Proposal/body}', (ROOT / 'Proposal/body.tex').read_text()))
